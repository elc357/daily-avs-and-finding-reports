<?php

require_once __DIR__ . "/../Controller/Controller.php";

use Controller\DataController;

// $test = new DataController();
// var_dump($test->entity());

// foreach ($test->entity() as $key => $value) {
//     echo $value . PHP_EOL;
// }

// foreach ($test->entity() as $key => $value) {
//     echo $value[0] . PHP_EOL;
// }

// $array = (array) $test->entity();

// foreach ($array as $key => $value) {
//     echo $value . PHP_EOL;
// }
