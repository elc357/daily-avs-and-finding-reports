<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $model['title'] ?></title>
</head>

<body>
    $model['finding-status']
    $model['finding-id']
    $model['finding-notif']


    <h1><?php echo $model['foo']
        ?></h1>
    <h1><?php echo $model['lorem']
        ?></h1>
    <h1><?php var_dump($model['post']) ?></h1>
</body>

</html>