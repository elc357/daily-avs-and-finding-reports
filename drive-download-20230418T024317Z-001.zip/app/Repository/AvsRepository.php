<?php

namespace AvsRepository {

    class AvsRepositoryImpl
    {
        public function save()
        {
        }
    }
}
