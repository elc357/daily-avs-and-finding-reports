<?php

namespace Middleware;

interface Middleware
{
    function before(): void;
}
